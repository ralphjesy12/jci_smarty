<div class="blog-post-item col-md-6 col-sm-6">

    <!-- IMAGE -->
    <figure class="margin-bottom-20">
        <img class="img-responsive" src="assets/images/demo/content_slider/10-min.jpg" alt="">
    </figure>

    <h2><a href="blog-single-default.html">BLOG IMAGE POST</a></h2>

    <ul class="blog-post-info list-inline">
        <li>
            <a href="#">
                <i class="fa fa-clock-o"></i>
                <span class="font-lato">June 29, 2015</span>
            </a>
        </li>
        <li>
            <a href="#">
                <i class="fa fa-comment-o"></i>
                <span class="font-lato">28 Comments</span>
            </a>
        </li>
        <li>
            <i class="fa fa-folder-open-o"></i>

            <a class="category" href="#">
                <span class="font-lato">Design</span>
            </a>
            <a class="category" href="#">
                <span class="font-lato">Photography</span>
            </a>
        </li>
        <li>
            <a href="#">
                <i class="fa fa-user"></i>
                <span class="font-lato">John Doe</span>
            </a>
        </li>
    </ul>

    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour.</p>

    <a href="blog-single-default.html" class="btn btn-reveal btn-default">
        <i class="fa fa-plus"></i>
        <span>Read More</span>
    </a>

</div>
