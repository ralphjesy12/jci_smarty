<?php
global $post;
get_header();
get_template_part('partials/category','');
get_footer();
?>
