<?php
global $post;
get_header();
get_template_part('partials/archive','');
get_footer();
?>
