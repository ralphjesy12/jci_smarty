<?php
global $post;
get_header();
get_template_part('partials/category','news');
get_footer();
?>
